package com.colorfast.adsdk.example.bean;

import com.colorfast.video.core.CFNativeVideo;

/**
 * Created by huangdong on 16/8/18.
 */
public class News {

    public CFNativeVideo ctNativeVideo;
    public com.colorfast.kern.core.CFAdvanceNative ctAdvanceNative;
    public String iconUrl;
    public String title;
    public String desc;
    public String choiceUrl;
    public String buttonStr;
    public boolean isAds = false;

}
